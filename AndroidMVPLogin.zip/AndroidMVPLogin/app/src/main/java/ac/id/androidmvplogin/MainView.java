package ac.id.androidmvplogin;

import java.util.List;

public interface MainView {
    void onLoad(List<User> users);

    void onSave();

    void onDelete();

    void onUpdate();
}

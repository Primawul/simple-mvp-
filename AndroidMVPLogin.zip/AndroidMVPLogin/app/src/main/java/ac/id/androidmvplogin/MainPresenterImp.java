package ac.id.androidmvplogin;

import java.util.ArrayList;
import java.util.List;

public class MainPresenterImp implements MainPresenter {

    private MainView mainView;
    private List<User> users = new ArrayList<>();
    private int no = 4;

    public MainPresenterImp(MainView mainView) {
        this.mainView = mainView;
        init();
    }

    private void init() {
        User user = new User();
        user.setId(1);
        user.setNama("Kristiawan Adi");
        user.setNoHp("085330684114");
        user.setPekerjaan("Java Programmer");
        user.setStatus("Jomblo sejak lahir");
        users.add(user);

        User user1 = new User();
        user1.setId(2);
        user1.setNama("Bimo Joko");
        user1.setNoHp("085474748888");
        user1.setPekerjaan("IT Scurity");
        user1.setStatus("Udah punya pacar tapi drama melulu");
        users.add(user1);

        User user2 = new User();
        user2.setId(3);
        user2.setNama("Dirga");
        user2.setNoHp("085332423043");
        user2.setPekerjaan("IT Security");
        user2.setStatus("Udah punya pacar dan bentar lagi nikah");
        users.add(user2);
    }

    @Override
    public void save(User user) {
        no++;
        user.setId(no);
        users.add(user);

        mainView.onSave();
    }

    @Override
    public void update(User user) {
        for (User model : users) {
            if (model.getId() == user.getId()) {
                model.setNama(user.getNama());
                model.setStatus(user.getStatus());
                model.setPekerjaan(user.getPekerjaan());
                model.setNoHp(user.getNoHp());

                break;
            }
        }
        mainView.onUpdate();
    }

    @Override
    public void delete(User user) {
        users.remove(user);

        mainView.onDelete();
    }

    @Override
    public void load() {
        mainView.onLoad(users);
    }
}